# معالجات اللغات (Language Processors)

هذا المجلد يحتوي على معالجات اللغات المختلفة لتحليل الكود المصدري.

## 📁 الملفات

### `base_processor.py`
المعالج الأساسي الذي يحدد الواجهة المشتركة لجميع معالجات اللغات.

### `python_processor.py`
معالج لغة Python المتقدم الذي يقوم بـ:
- تحليل بناء الجملة (AST)
- استخراج الميزات (عدد الأسطر، الدوال)
- استخراج التبعيات
- **تحليل علاقات التركيب من `__init__`**
- توليد مخططات الفئات مع العلاقات

### `java_processor.py`
معالج لغة Java المتقدم الذي يقوم بـ:
- تحليل بناء الجملة باستخدام Tree-sitter
- استخراج الميزات (عدد الأسطر، الطرق)
- استخراج التبعيات
- **تحليل علاقات التركيب من البناء (constructor)**
- توليد مخططات الفئات مع العلاقات

## 🔍 تحليل العلاقات

### Python - تحليل `__init__`
```python
class Car:
    def __init__(self):
        self.engine = Engine()  # ← يتم اكتشاف هذه العلاقة
```

### Java - تحليل Constructor
```java
public class Car {
    public Car() {
        this.engine = new Engine();  // ← يتم اكتشاف هذه العلاقة
    }
}
```

## 📊 النتائج

كلا المعالجين ينتجان نفس تنسيق البيانات:

```json
{
  "classes": [
    {
      "name": "Car",
      "methods": ["__init__()", "drive()"],
      "associations": [
        {
          "target_class": "Engine",
          "type": "Composition",
          "attribute": "engine"
        }
      ]
    }
  ]
}
```

## 🛠️ إضافة لغة جديدة

لإضافة معالج لغة جديدة:

1. أنشئ ملف `[language]_processor.py`
2. ورث من `ILanguageProcessorStrategy`
3. نفذ جميع الطرق المطلوبة
4. أضف المعالج إلى `analyze_code.py`

### مثال:
```python
from .base_processor import ILanguageProcessorStrategy

class NewLanguageProcessor(ILanguageProcessorStrategy):
    def parse_source_code(self, code_content: str):
        # تنفيذ التحليل
        pass

    def extract_features(self, ast_data):
        # استخراج الميزات
        pass

    # ... باقي الطرق
```

## ⚡ الأداء

- **Python**: يستخدم AST مدمج (سريع جداً)
- **Java**: يستخدم Tree-sitter (محسن للغات متعددة)
- **كلا المعالجين**: ينتجان نفس جودة التحليل